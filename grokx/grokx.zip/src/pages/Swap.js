import SwapLayout from "../components/swap/layout";

function Swap() {
    return ( 
        <div>
            <div
                className="centered"
                style={{
                minHeight: "85vh"
            }}>
                <SwapLayout />
            </div>
        </div>
     );
}

export default Swap;