import StakeLayout from "../components/stake/layout";

function Stake() {
    return ( 
        <div>
        <div
            className="centered"
            style={{
            minHeight: "85vh"
        }}>
            <StakeLayout />
        </div>
    </div>
     );
}

export default Stake;