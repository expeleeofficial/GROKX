import { bscTestnet, bsc, mainnet } from "viem/chains"


export const tokensMap = {
    eth: {
        chain:mainnet,
        apiKey:"MF1NI5KFYEIY28Q9ISW2A367M8BREZR1UR",
        router:"0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D",
        vault:"0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D",
        explorer:"https://api.etherscan.io/api",
        tokens: [
            {
                name: 'ETH',
                logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.svg?v=013',
                address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
                balance: 0
            }, {
                name: 'SCB',
                logo: 'https://cryptologos.cc/logos/binance-usd-busd-logo.svg?v=013',
                address: '0xD6DF0d54e016c2ab3Eeb292daa97c2F4f290914b',
                balance: 0
            }, {
                name: 'USDT',
                logo: 'https://cryptologos.cc/logos/tether-usdt-logo.svg?v=013',
                address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
                balance: 0
            }
        ]
    },
    bsc: {
        chain:bsc,
        apiKey:"KZI76Y51VFWV613MJ8II1R8QCCBDUSA1TF",
        router:"0x10ed43c718714eb63d5aa57b78b54704e256024e",
        vault:"0x10ed43c718714eb63d5aa57b78b54704e256024e",
        explorer:"https://api.bscscan.com/api",
        tokens: [
            {
                name: 'BNB',
                logo: 'https://cryptologos.cc/logos/binance-coin-bnb-logo.svg?v=013',
                address: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
                balance: 0
            }, {
                name: 'SCB',
                logo: 'https://cryptologos.cc/logos/binance-usd-busd-logo.svg?v=013',
                address: '0xD6DF0d54e016c2ab3Eeb292daa97c2F4f290914b',
                balance: 0
            }, {
                name: 'USDT',
                logo: 'https://cryptologos.cc/logos/tether-usdt-logo.svg?v=013',
                address: '0x55d398326f99059fF775485246999027B3197955',
                balance: 0
            }, {
                name: 'BUSD',
                logo: 'https://cryptologos.cc/logos/binance-usd-busd-logo.svg?v=013',
                address: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
                balance: 0
            }
        ]
    },
    testnet: {
        chain: bscTestnet,
        apiKey:undefined,
        router:"0xd99d1c33f9fc3444f8101754abc46c52416550d1",
        vault:"0xd99d1c33f9fc3444f8101754abc46c52416550d1",
        explorer:"https://api-testnet.bscscan.com/api",
        tokens: [
            {
                name: 'BNB',
                logo: 'https://cryptologos.cc/logos/binance-coin-bnb-logo.svg?v=013',
                address: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
                balance: 0
            }, {
                name: 'SCB',
                logo: 'https://cryptologos.cc/logos/binance-usd-busd-logo.svg?v=013',
                address: '0xD6DF0d54e016c2ab3Eeb292daa97c2F4f290914b',
                balance: 0
            }, {
                name: 'USDT',
                logo: 'https://cryptologos.cc/logos/tether-usdt-logo.svg?v=013',
                address: '0x235ea4f6ba06c44e2de817a234052e19dd961fde',
                balance: 0
            }, {
                name: 'BUSD',
                logo: 'https://cryptologos.cc/logos/binance-usd-busd-logo.svg?v=013',
                address: '0x25d95a65e8db891116511672ebdabec33851c19b',
                balance: 0
            }
        ]
    }

}